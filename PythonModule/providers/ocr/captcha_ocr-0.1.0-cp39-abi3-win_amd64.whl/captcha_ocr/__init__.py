from .captcha_ocr import *

__doc__ = captcha_ocr.__doc__
if hasattr(captcha_ocr, "__all__"):
    __all__ = captcha_ocr.__all__