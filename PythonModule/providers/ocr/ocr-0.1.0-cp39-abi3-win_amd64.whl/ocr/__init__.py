from .ocr import *

__doc__ = ocr.__doc__
if hasattr(ocr, "__all__"):
    __all__ = ocr.__all__